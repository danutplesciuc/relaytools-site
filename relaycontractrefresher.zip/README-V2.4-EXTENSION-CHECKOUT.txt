Relay Contract Refresher V2.4 EXTENSION CHECKOUT

WHAT IS NEW:
- Popup now has Start 7 Day Free Trial button.
- Button opens Stripe Checkout.
- User enters email, starts trial, Stripe creates subscription.
- Webhook creates license automatically on server.

INSTALL EXTENSION:
1. chrome://extensions
2. Remove old extension
3. Load unpacked
4. Select the extension folder from this package

SERVER REQUIRED:
Your server must already have:
- /create-checkout-session
- /stripe/webhook
- STRIPE_PRICE_ID
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- APP_URL

TEST:
1. Open extension popup
2. Enter email
3. Click Start 7 Day Free Trial
4. Stripe Checkout should open
