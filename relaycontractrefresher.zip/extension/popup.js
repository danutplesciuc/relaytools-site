const CONFIG_KEY = 'rcr_config_v150';
const CURRENT_VERSION = '2.6.0';

const defaults = {
  minRefresh: 15,
  maxRefresh: 25,
  autoStop: true,
  soundEnabled: true,
  telegramEnabled: true,
  telegramBotToken: '',
  telegramChatId: '',
  licenseEmail: '',
  licenseKey: '',
  licenseValid: false,
  licenseStatus: 'inactive',
  licenseExpires: '',
  licenseApiUrl: 'https://relay-license-server.onrender.com/validate-license'
};

function $(id) { return document.getElementById(id); }

let userIsTyping = false;
let typingTimer = null;
let initialLoaded = false;

const editableIds = [
  'minRefresh',
  'maxRefresh',
  'telegramBotToken',
  'telegramChatId',
  'licenseEmail',
  'licenseKey',
  'licenseApiUrl'
];

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToContent(type) {
  const tab = await getActiveTab();
  if (!tab || !tab.id) return;
  chrome.tabs.sendMessage(tab.id, { type }, () => {});
}

function isLicenseActive(data) {
  if (!data.licenseValid) return false;
  if (!data.licenseExpires) return false;
  return new Date(data.licenseExpires).getTime() > Date.now();
}

function renderLicense(data) {
  const active = isLicenseActive(data);
  const status = $('licenseStatus');

  if (active) {
    const expiry = new Date(data.licenseExpires).toLocaleDateString();
    status.textContent = `ACTIVE • Expires ${expiry}`;
    status.className = 'license-status good';
  } else if (data.licenseStatus === 'checking') {
    status.textContent = 'Checking license...';
    status.className = 'license-status warn';
  } else {
    status.textContent = data.licenseStatus === 'expired' ? 'EXPIRED' : 'NOT ACTIVATED';
    status.className = 'license-status bad';
  }

  $('start').disabled = !active;
  $('test').disabled = !active;
}

function setFieldValue(id, value) {
  const el = $(id);
  if (!el) return;
  if (document.activeElement === el) return;
  el.value = value ?? '';
}

function setCheckboxValue(id, value) {
  const el = $(id);
  if (!el) return;
  if (document.activeElement === el) return;
  el.checked = !!value;
}

function loadInitialSettings() {
  chrome.storage.sync.get(Object.keys(defaults).concat(CONFIG_KEY), data => {
    const cfg = data[CONFIG_KEY] || {};

    setFieldValue('minRefresh', data.minRefresh ?? cfg.minRefresh ?? defaults.minRefresh);
    setFieldValue('maxRefresh', data.maxRefresh ?? cfg.maxRefresh ?? defaults.maxRefresh);
    setCheckboxValue('autoStop', data.autoStop ?? cfg.autoStop ?? defaults.autoStop);
    setCheckboxValue('soundEnabled', data.soundEnabled ?? cfg.sound ?? defaults.soundEnabled);
    setCheckboxValue('telegramEnabled', data.telegramEnabled ?? cfg.telegram ?? defaults.telegramEnabled);
    setFieldValue('telegramBotToken', data.telegramBotToken || '');
    setFieldValue('telegramChatId', data.telegramChatId || '');
    setFieldValue('licenseEmail', data.licenseEmail || '');
    setFieldValue('licenseKey', data.licenseKey || '');
    setFieldValue('licenseApiUrl', data.licenseApiUrl || defaults.licenseApiUrl);

    renderLicense(data);
    initialLoaded = true;
  });
}

function refreshStatusOnly() {
  chrome.storage.local.get(['rcrLastStatus', 'rcrCountdown'], data => {
    $('status').textContent = data.rcrLastStatus || 'Open Amazon Relay contracts page';
    $('countdown').textContent = data.rcrCountdown || 'No active timer yet';
  });

  chrome.storage.sync.get(['licenseValid', 'licenseStatus', 'licenseExpires'], data => {
    renderLicense(data);
  });
}

function saveTypingDraft() {
  chrome.storage.local.set({
    rcrDraftEmail: $('licenseEmail').value,
    rcrDraftKey: $('licenseKey').value,
    rcrDraftBotToken: $('telegramBotToken').value,
    rcrDraftChatId: $('telegramChatId').value
  });
}

function markTyping() {
  userIsTyping = true;
  saveTypingDraft();
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    userIsTyping = false;
  }, 1500);
}

function save() {
  let minRefresh = Number($('minRefresh').value) || 15;
  let maxRefresh = Number($('maxRefresh').value) || 25;
  if (maxRefresh <= minRefresh) maxRefresh = minRefresh + 5;

  const cfgForContent = {
    enabled: true,
    autoStop: $('autoStop').checked,
    sound: $('soundEnabled').checked,
    telegram: $('telegramEnabled').checked,
    minRefresh,
    maxRefresh,
    panelVisible: true
  };

  chrome.storage.sync.set({
    [CONFIG_KEY]: cfgForContent,
    minRefresh,
    maxRefresh,
    autoStop: $('autoStop').checked,
    soundEnabled: $('soundEnabled').checked,
    telegramEnabled: $('telegramEnabled').checked,
    telegramBotToken: $('telegramBotToken').value.trim(),
    telegramChatId: $('telegramChatId').value.trim(),
    licenseApiUrl: $('licenseApiUrl').value.trim() || defaults.licenseApiUrl
  }, () => {
    $('saved').textContent = 'Saved. Refresh Amazon Relay page once.';
    setTimeout(() => $('saved').textContent = '', 3000);
  });
}

function activateLicense() {
  const email = $('licenseEmail').value.trim().toLowerCase();
  const key = $('licenseKey').value.trim().toUpperCase();
  const licenseApiUrl = $('licenseApiUrl').value.trim() || defaults.licenseApiUrl;

  if (!email || !key) {
    $('saved').textContent = 'Add email and license key first.';
    return;
  }

  chrome.storage.sync.set({ licenseEmail: email, licenseKey: key, licenseApiUrl, licenseStatus: 'checking' }, () => {
    renderLicense({ licenseStatus: 'checking' });
  });

  chrome.runtime.sendMessage({ type: 'VERIFY_LICENSE', email, key }, response => {
    if (response && response.ok && response.active) {
      chrome.storage.sync.set({
        licenseEmail: email,
        licenseKey: key,
        licenseValid: true,
        licenseStatus: 'active',
        licenseExpires: response.expiresAt,
        licenseCheckedAt: new Date().toISOString()
      }, () => {
        $('saved').textContent = 'License activated.';
        refreshStatusOnly();
      });
    } else {
      chrome.storage.sync.set({
        licenseEmail: email,
        licenseKey: key,
        licenseValid: false,
        licenseStatus: response?.reason || 'inactive',
        licenseExpires: '',
  licenseApiUrl: 'https://relay-license-server.onrender.com/validate-license'
      }, () => {
        $('saved').textContent = 'License not active.';
        refreshStatusOnly();
      });
    }
  });
}

function clearLicense() {
  chrome.storage.sync.set({
    licenseEmail: '',
    licenseKey: '',
    licenseValid: false,
    licenseStatus: 'inactive',
    licenseExpires: '',
  licenseApiUrl: 'https://relay-license-server.onrender.com/validate-license'
  }, () => {
    $('licenseEmail').value = '';
    $('licenseKey').value = '';
    $('saved').textContent = 'License cleared.';
    refreshStatusOnly();
    sendToContent('RCR_STOP');
  });
}


function checkUpdate() {
  const el = $('updateStatus');
  const link = $('downloadUpdate');
  if (el) el.textContent = 'Checking update...';
  if (link) link.style.display = 'none';

  const apiUrl = ($('licenseApiUrl')?.value || defaults.licenseApiUrl).trim();
  chrome.runtime.sendMessage({ type: 'CHECK_UPDATE', apiUrl, currentVersion: CURRENT_VERSION }, response => {
    if (!response || !response.ok) {
      if (el) el.textContent = 'Update check failed. Check server URL.';
      return;
    }

    if (response.updateAvailable) {
      if (el) el.textContent = `Update available: v${response.latestVersion}. Current: v${CURRENT_VERSION}`;
      if (link && response.downloadUrl) {
        link.href = response.downloadUrl;
        link.style.display = 'block';
      }
    } else {
      if (el) el.textContent = `You are up to date. v${CURRENT_VERSION}`;
    }
  });
}



async function autoActivateLicense(email) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({
      type: 'FETCH_AUTO_LICENSE',
      email
    }, response => {
      if (!response || !response.ok || !response.licenseKey) {
        resolve(false);
        return;
      }

      $('licenseKey').value = response.licenseKey;

      chrome.storage.sync.set({
        licenseEmail: email,
        licenseKey: response.licenseKey
      }, () => {
        if (typeof activateLicense === 'function') {
          activateLicense();
        }

        resolve(true);
      });
    });
  });
}


function startTrialCheckout() {
  const email = $('licenseEmail').value.trim().toLowerCase();

  if (!email) {
    const msg = $('trialMsg');
    if (msg) msg.textContent = 'Enter your email first.';
    $('saved').textContent = 'Enter your email first.';
    return;
  }

  chrome.storage.sync.set({ licenseEmail: email }, () => {});

  const msg = $('trialMsg');
  if (msg) msg.textContent = 'Opening secure Stripe Checkout...';

  
  chrome.runtime.sendMessage({ type: 'START_TRIAL_CHECKOUT', email }, response => {
    if (response && response.ok) {
      if (msg) msg.textContent = 'Stripe Checkout opened. Waiting for activation...';
      $('saved').textContent = 'Stripe Checkout opened.';

      let tries = 0;

      const timer = setInterval(async () => {
        tries++;

        const activated = await autoActivateLicense(email);

        if (activated) {
          clearInterval(timer);

          if (msg) msg.textContent = 'License activated automatically.';
          $('saved').textContent = 'License activated automatically.';
          return;
        }

        if (tries >= 30) {
          clearInterval(timer);

          if (msg) msg.textContent = 'Waiting for payment completion.';
        }
      }, 5000);

    } else {
      const error = response?.error || 'Could not open checkout.';
      if (msg) msg.textContent = error;
      $('saved').textContent = error;
    }
  });

}


function wireEvents() {
  $('save').addEventListener('click', save);
  $('activate').addEventListener('click', activateLicense);
  $('clearLicense').addEventListener('click', clearLicense);
  $('start').addEventListener('click', () => sendToContent('RCR_START'));
  $('stop').addEventListener('click', () => sendToContent('RCR_STOP'));
  $('test').addEventListener('click', () => sendToContent('RCR_TEST'));
  $('baseline').addEventListener('click', () => sendToContent('RCR_BASELINE'));
  $('panel').addEventListener('click', () => sendToContent('RCR_TOGGLE_PANEL'));
  $('checkUpdate')?.addEventListener('click', checkUpdate);
  $('startTrial')?.addEventListener('click', startTrialCheckout);

  editableIds.forEach(id => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('input', markTyping);
    el.addEventListener('focus', () => { userIsTyping = true; });
    el.addEventListener('blur', () => {
      setTimeout(() => { userIsTyping = false; }, 300);
    });
  });
}

wireEvents();
loadInitialSettings();
refreshStatusOnly();
setInterval(refreshStatusOnly, 1000);
setTimeout(checkUpdate, 1200);
