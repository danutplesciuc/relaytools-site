
const DEMO_LICENSE_KEY = 'RCR-DEMO-2026';
const DEFAULT_LICENSE_SERVER_URL = 'https://relay-license-server.onrender.com/validate-license';


async function getOrCreateDeviceId() {
  return new Promise(resolve => {
    chrome.storage.local.get(['rcrDeviceId'], data => {
      if (data.rcrDeviceId) {
        resolve(data.rcrDeviceId);
        return;
      }

      const deviceId =
        'DEV-' +
        Math.random().toString(36).substring(2, 10).toUpperCase() +
        '-' +
        Date.now().toString(36).toUpperCase();

      chrome.storage.local.set({ rcrDeviceId: deviceId }, () => {
        resolve(deviceId);
      });
    });
  });
}

function demoExpiryDate() {
  const d = new Date();
  d.setDate(d.getDate() + 30);
  return d.toISOString();
}

function getSync(keys) {
  return new Promise(resolve => chrome.storage.sync.get(keys, resolve));
}

async function verifyLicense(email, key) {
  const cfg = await getSync(['licenseApiUrl']);
  const apiUrl = (cfg.licenseApiUrl || DEFAULT_LICENSE_SERVER_URL).trim();
  const deviceId = await getOrCreateDeviceId();

  if (apiUrl) {
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          license_key: key,
          product: 'relay-contract-refresher',
          extension_version: chrome.runtime.getManifest().version,
          deviceId
        })
      });

      if (!response.ok) {
        return { ok: false, active: false, reason: `server_error_${response.status}` };
      }

      return await response.json();
    } catch (error) {
      // Fallback demo mode, only for local testing.
      if (key === DEMO_LICENSE_KEY) {
        return { ok: true, active: true, expiresAt: demoExpiryDate(), plan: 'demo-local-fallback' };
      }
      return { ok: false, active: false, reason: 'license_server_offline' };
    }
  }

  if (key === DEMO_LICENSE_KEY) {
    return { ok: true, active: true, expiresAt: demoExpiryDate(), plan: 'demo' };
  }

  return { ok: true, active: false, reason: 'inactive' };
}


function compareVersions(a, b) {
  const pa = String(a || '0').split('.').map(Number);
  const pb = String(b || '0').split('.').map(Number);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const na = pa[i] || 0;
    const nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

async function checkUpdate(apiUrl, currentVersion) {
  const baseUrl = String(apiUrl || DEFAULT_LICENSE_SERVER_URL).replace(/\/validate-license\/?$/, '');
  const versionUrl = baseUrl.replace(/\/$/, '') + '/version';
  const response = await fetch(versionUrl, { method: 'GET' });
  if (!response.ok) return { ok: false, error: `server_error_${response.status}` };
  const data = await response.json();
  const latestVersion = data.version || data.latestVersion || '0.0.0';
  return {
    ok: true,
    currentVersion,
    latestVersion,
    updateAvailable: compareVersions(latestVersion, currentVersion) > 0,
    downloadUrl: data.downloadUrl || data.download || '',
    notes: data.notes || ''
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;


  if (message.type === 'FETCH_AUTO_LICENSE') {
    (async () => {
      try {
        const email = String(message.email || '').trim().toLowerCase();

        const response = await fetch('https://relay-license-server.onrender.com/get-license-by-email', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-rcr-secret': 'RCR_SECURE_2026'
          },
          body: JSON.stringify({ email })
        });

        const data = await response.json();

        if (!data || !data.ok || !data.licenseKey) {
          sendResponse({
            ok: false,
            error: 'license_not_found'
          });
          return;
        }

        sendResponse({
          ok: true,
          licenseKey: data.licenseKey || '',
          plan: data.plan || 'pro'
        });

      } catch (error) {
        sendResponse({
          ok: false,
          error: String(error)
        });
      }
    })();

    return true;
  }



  if (message.type === 'START_TRIAL_CHECKOUT') {
    (async () => {
      try {
        const email = String(message.email || '').trim().toLowerCase();

        if (!email) {
          sendResponse({ ok: false, error: 'email_required' });
          return;
        }

        const response = await fetch('https://relay-license-server.onrender.com/create-checkout-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });

        const data = await response.json();

        if (!response.ok || !data.url) {
          sendResponse({ ok: false, error: data.error || 'checkout_failed' });
          return;
        }

        chrome.tabs.create({ url: data.url });
        sendResponse({ ok: true, url: data.url });

      } catch (error) {
        sendResponse({ ok: false, error: String(error) });
      }
    })();

    return true;
  }


  if (message.type === 'CHECK_UPDATE') {
    checkUpdate(message.apiUrl, message.currentVersion || chrome.runtime.getManifest().version)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, error: String(error) }));
    return true;
  }

  if (message.type === 'VERIFY_LICENSE') {
    verifyLicense(message.email, message.key)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ ok: false, active: false, reason: String(error) }));
    return true;
  }

  if (message.type !== 'SEND_TELEGRAM') return;

  chrome.storage.sync.get(['telegramEnabled', 'telegramBotToken', 'telegramChatId'], async (cfg) => {
    if (!cfg.telegramEnabled) {
      sendResponse({ ok: false, skipped: true, reason: 'Telegram disabled' });
      return;
    }

    if (!cfg.telegramBotToken || !cfg.telegramChatId) {
      sendResponse({ ok: false, skipped: true, reason: 'Missing Telegram settings' });
      return;
    }

    try {
      const response = await fetch(`https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: cfg.telegramChatId, text: message.text })
      });

      sendResponse({ ok: response.ok });
    } catch (error) {
      sendResponse({ ok: false, error: String(error) });
    }
  });

  return true;
});
