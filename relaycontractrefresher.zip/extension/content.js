(function () {
  'use strict';

  if (window.__relayContractRefresherLoaded) return;
  window.__relayContractRefresherLoaded = true;

  const CONFIG_KEY = 'rcr_config_v130';
  const STATE_KEY = 'rcr_state_v130';

  const defaultConfig = {
    enabled: true,
    autoStop: true,
    sound: true,
    telegram: true,
    minRefresh: 15,
    maxRefresh: 25,
    panelVisible: true
  };

  let config = { ...defaultConfig };
  let countdownTimer = null;
  let scanTimer = null;
  let flashInterval = null;
  let originalTitle = document.title;

  async function init() {
    await loadConfig();
    createPanel();

    if (config.enabled && await licenseIsActive()) {
      setTimeout(autoBaseline, 1500);
      setTimeout(scanContracts, 3000);
      scanTimer = setInterval(scanContracts, 3000);
      startCountdown();
    } else if (config.enabled) {
      config.enabled = false;
      setStatus('License required. Activate from extension popup.');
    }

    listenForPopupMessages();
    updateButtons();
    setStatus(config.enabled ? 'System ready' : 'System stopped');
    checkLicenseOnLoad();
  }

  function chromeGet(keys) {
    return new Promise(resolve => chrome.storage.sync.get(keys, resolve));
  }

  function chromeSet(data) {
    return new Promise(resolve => chrome.storage.sync.set(data, resolve));
  }

  async function loadConfig() {
    const saved = await chromeGet(CONFIG_KEY);
    config = { ...defaultConfig, ...(saved[CONFIG_KEY] || {}) };
  }

  async function saveConfig() {
    await chromeSet({ [CONFIG_KEY]: config });
    await chromeSet({
      minRefresh: config.minRefresh,
      maxRefresh: config.maxRefresh,
      autoStop: config.autoStop,
      soundEnabled: config.sound,
      telegramEnabled: config.telegram
    });
  }


  function chromeGetSync(keys) {
    return new Promise(resolve => chrome.storage.sync.get(keys, resolve));
  }

  async function licenseIsActive() {
    const data = await chromeGetSync(['licenseValid', 'licenseExpires']);
    if (!data.licenseValid || !data.licenseExpires) return false;
    return new Date(data.licenseExpires).getTime() > Date.now();
  }

  async function checkLicenseOnLoad() {
    if (!(await licenseIsActive())) {
      stopSystem('LICENSE REQUIRED');
      chrome.storage.local.set({ rcrLastStatus: 'License required. Activate from extension popup.' });
    }
  }

  function loadState() {
    try {
      return JSON.parse(localStorage.getItem(STATE_KEY) || '{}');
    } catch {
      return {};
    }
  }

  function saveState(data) {
    localStorage.setItem(STATE_KEY, JSON.stringify(data));
  }

  function sendTelegram(msg) {
    if (!config.telegram) return;
    try {
      chrome.runtime.sendMessage({ type: 'SEND_TELEGRAM', text: msg });
    } catch {}
  }

  function beep() {
    if (!config.sound) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.value = 1700;
      gain.gain.value = 0.35;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      setTimeout(() => {
        osc.stop();
        ctx.close();
      }, 900);
    } catch {}
  }

  function flashTitle() {
    if (flashInterval) return;
    flashInterval = setInterval(() => {
      document.title = document.title.includes('🔥') ? originalTitle : '🔥 PRICE / CONTRACT CHANGE';
    }, 700);
  }

  function stopFlash() {
    if (flashInterval) clearInterval(flashInterval);
    flashInterval = null;
    document.title = originalTitle;
  }

  function clickRelayRefreshButton() {
    const svgPath = [...document.querySelectorAll('svg path')]
      .find(p => (p.getAttribute('d') || '').includes('M20.128'));

    if (!svgPath) {
      setStatus('Refresh button not found.');
      return false;
    }

    const svg = svgPath.closest('svg');
    const target = svg.closest('button') || svg.closest('[role="button"]') || svg.parentElement;

    if (!target) {
      setStatus('Refresh target not found.');
      return false;
    }

    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(type => {
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });

    setStatus('Clicked Relay refresh button.');
    return true;
  }

  function getResultsCount() {
    const match = document.body.innerText.match(/Showing\s+\d+\-\d+\s+of\s+(\d+)\s+results/i);
    return match ? parseInt(match[1], 10) : null;
  }

  function getRows() {
    const all = [...document.querySelectorAll('div, tr, section, article')];
    const rows = all.filter(el => {
      const text = el.innerText || '';
      return (
        text.includes('£') &&
        text.includes('UK') &&
        text.length > 40 &&
        text.length < 1600 &&
        !text.includes('Relay Contract Refresher') &&
        !text.includes('SYSTEM STOPPED')
      );
    });
    return uniqueRows(rows.map(getBestRowContainer).filter(Boolean));
  }

  function getBestRowContainer(el) {
    let current = el;
    let best = el;

    for (let i = 0; i < 7 && current && current.parentElement; i++) {
      const parent = current.parentElement;
      const text = parent.innerText || '';
      const rect = parent.getBoundingClientRect();
      const looksLikeFullRow =
        text.includes('£') &&
        text.includes('UK') &&
        rect.width > window.innerWidth * 0.65 &&
        rect.height > 45 &&
        rect.height < 260 &&
        text.length < 2500;

      if (looksLikeFullRow) best = parent;
      current = parent;
    }

    return best;
  }

  function uniqueRows(rows) {
    const seen = new Set();
    return rows.filter(row => {
      const sig = getSignature(row);
      if (seen.has(sig)) return false;
      seen.add(sig);
      return true;
    });
  }

  function getSignature(row) {
    return row.innerText.replace(/\s+/g, ' ').trim().slice(0, 900);
  }

  function extractPrice(text) {
    const matches = [...text.matchAll(/£\s?([\d,]+(?:\.\d{1,2})?)/g)];
    if (!matches.length) return null;
    return Number(matches[0][1].replace(/,/g, ''));
  }

  function getStableKey(row) {
    return row.innerText
      .replace(/£\s?[\d,]+(?:\.\d{1,2})?/g, '£PRICE')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 650);
  }

  function getRowData() {
    return getRows().map(row => {
      const text = row.innerText || '';
      return { row, sig: getSignature(row), key: getStableKey(row), price: extractPrice(text), text };
    });
  }

  function setStatus(text) {
    const el = document.getElementById('rcr-status');
    if (el) el.textContent = text;
    chrome.storage.local.set({ rcrLastStatus: text, rcrLastSeen: new Date().toLocaleTimeString() });
  }

  function autoBaseline() {
    const data = getRowData();
    saveState({
      ready: true,
      count: getResultsCount(),
      rows: data.map(x => x.sig),
      items: data.map(x => ({ key: x.key, sig: x.sig, price: x.price }))
    });
    setStatus('Baseline ready');
  }

  function paintRow(row, type, diffText) {
    const isDown = type === 'down';
    const bg = isDown ? '#fecaca' : '#86efac';
    const border = isDown ? '#dc2626' : '#16a34a';
    const shadow = isDown ? '#dc2626' : '#16a34a';

    row.style.setProperty('background', bg, 'important');
    row.style.setProperty('background-color', bg, 'important');
    row.style.setProperty('box-shadow', `inset 0 0 0 9999px ${isDown ? 'rgba(254,202,202,0.78)' : 'rgba(134,239,172,0.78)'}, 0 0 35px ${shadow}`, 'important');
    row.style.setProperty('outline', `4px solid ${border}`, 'important');
    row.style.setProperty('position', 'relative', 'important');

    row.querySelectorAll('*').forEach(child => {
      const text = child.innerText || '';
      const isAcceptButton = text.trim() === 'Accept' || child.tagName === 'BUTTON' || child.querySelector?.('button');
      if (isAcceptButton) return;
      child.style.setProperty('background', 'transparent', 'important');
      child.style.setProperty('background-color', 'transparent', 'important');
    });

    if (diffText && !row.querySelector('.rcr-price-diff')) {
      const badge = document.createElement('div');
      badge.className = 'rcr-price-diff';
      badge.textContent = diffText;
      badge.style.cssText = `
        position:absolute;
        right:260px;
        top:10px;
        z-index:99999;
        background:${isDown ? '#dc2626' : '#16a34a'};
        color:white;
        padding:7px 12px;
        border-radius:12px;
        font-weight:900;
        font-size:14px;
        box-shadow:0 6px 16px rgba(0,0,0,.28);
        pointer-events:none;
      `;
      row.appendChild(badge);
    }

    try { row.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch {}
  }

  async function stopSystem(reason = 'SYSTEM STOPPED') {
    config.enabled = false;
    await saveConfig();
    if (scanTimer) clearInterval(scanTimer);
    if (countdownTimer) clearInterval(countdownTimer);
    stopFlash();
    setStatus(reason);
    const countdown = document.getElementById('rcr-countdown');
    if (countdown) {
      countdown.textContent = reason;
      countdown.style.color = '#ef4444';
    }
    updateButtons();
  }

  async function startSystem() {
    if (!(await licenseIsActive())) {
      config.enabled = false;
      await saveConfig();
      setStatus('License required. Activate from extension popup.');
      updateButtons();
      return;
    }

    config.enabled = true;
    await saveConfig();
    autoBaseline();
    if (scanTimer) clearInterval(scanTimer);
    scanTimer = setInterval(scanContracts, 3000);
    startCountdown();
    setStatus('SYSTEM STARTED');
    updateButtons();
  }

  function updateButtons() {
    const stopBtn = document.getElementById('rcr-stop');
    const startBtn = document.getElementById('rcr-start');
    if (!stopBtn || !startBtn) return;
    stopBtn.disabled = !config.enabled;
    startBtn.disabled = config.enabled;
    stopBtn.style.opacity = config.enabled ? '1' : '.45';
    startBtn.style.opacity = config.enabled ? '.45' : '1';
  }

  async function saveRefreshSettings() {
    config.minRefresh = Number(document.getElementById('rcr-min').value) || 15;
    config.maxRefresh = Number(document.getElementById('rcr-max').value) || 25;
    config.autoStop = document.getElementById('rcr-autostop').checked;
    config.sound = document.getElementById('rcr-sound').checked;
    config.telegram = document.getElementById('rcr-telegram').checked;

    if (config.maxRefresh <= config.minRefresh) config.maxRefresh = config.minRefresh + 5;
    await saveConfig();
    startCountdown();
  }

  function scanContracts() {
    if (!config.enabled) return;

    const currentData = getRowData();
    const currentRows = currentData.map(x => x.sig);
    const currentCount = getResultsCount();
    const oldState = loadState();

    if (!oldState.ready) {
      autoBaseline();
      return;
    }

    const oldRows = oldState.rows || [];
    const oldItems = oldState.items || [];
    const oldByKey = new Map(oldItems.map(x => [x.key, x]));
    const changes = [];

    currentData.forEach(item => {
      const old = oldByKey.get(item.key);
      if (old && old.price !== null && item.price !== null && old.price !== item.price) {
        const diff = item.price - old.price;
        changes.push({ item, type: diff > 0 ? 'up' : 'down', oldPrice: old.price, newPrice: item.price, diff });
        return;
      }

      if (!oldRows.includes(item.sig)) {
        changes.push({ item, type: 'new', oldPrice: null, newPrice: item.price, diff: null });
      }
    });

    const countChanged = currentCount !== oldState.count;

    if (changes.length > 0 || countChanged) {
      saveState({
        ready: true,
        count: currentCount,
        rows: currentRows,
        items: currentData.map(x => ({ key: x.key, sig: x.sig, price: x.price }))
      });

      const telegramLines = [];
      changes.forEach(change => {
        let label = '🟢 NEW CONTRACT';
        if (change.type === 'up') {
          label = `🟢 PRICE UP +£${Math.abs(change.diff).toLocaleString()}`;
          paintRow(change.item.row, 'up', `+£${Math.abs(change.diff).toLocaleString()}`);
        } else if (change.type === 'down') {
          label = `🔴 PRICE DOWN -£${Math.abs(change.diff).toLocaleString()}`;
          paintRow(change.item.row, 'down', `-£${Math.abs(change.diff).toLocaleString()}`);
        } else {
          paintRow(change.item.row, 'up', 'NEW');
        }
        telegramLines.push(`${label}\n${change.item.text.split('\n').slice(0, 5).join(' | ')}`);
      });

      beep();
      flashTitle();
      setTimeout(stopFlash, 120000);

      sendTelegram(`🔥 RELAY CONTRACT REFRESHER\nResults: ${oldState.count} → ${currentCount}\nChanges: ${changes.length}\n\n${telegramLines.slice(0, 5).join('\n\n')}`);
      setStatus(`🔥 CHANGE DETECTED ${oldState.count} → ${currentCount} • ${changes.length} changes`);

      chrome.storage.local.get(['rcrStats'], data => {
        const stats = data.rcrStats || { detectedToday: 0, priceChangesToday: 0, date: new Date().toDateString() };
        if (stats.date !== new Date().toDateString()) {
          stats.detectedToday = 0;
          stats.priceChangesToday = 0;
          stats.date = new Date().toDateString();
        }
        stats.detectedToday += changes.filter(c => c.type === 'new').length;
        stats.priceChangesToday += changes.filter(c => c.type === 'up' || c.type === 'down').length;
        chrome.storage.local.set({ rcrStats: stats });
      });

      if (config.autoStop) stopSystem('🔥 AUTO STOPPED AFTER CHANGE');
      return;
    }

    setStatus(`No change • ${new Date().toLocaleTimeString()}`);
  }

  function startCountdown() {
    if (countdownTimer) clearInterval(countdownTimer);
    if (!config.enabled) return;

    const min = Math.max(5, config.minRefresh);
    const max = Math.max(min + 1, config.maxRefresh);
    let left = Math.floor(min + Math.random() * (max - min + 1));
    const el = document.getElementById('rcr-countdown');

    const tick = () => {
      if (!config.enabled) return;
      if (!el) return;
      el.textContent = `Click refresh in ${left}s • ${min}-${max}s`;
      chrome.storage.local.set({ rcrCountdown: el.textContent });
      if (left <= 0) {
        clickRelayRefreshButton();
        setTimeout(() => {
          scanContracts();
          startCountdown();
        }, 2500);
        return;
      }
      left--;
    };

    tick();
    countdownTimer = setInterval(tick, 1000);
  }

  function createPanel() {
    if (document.getElementById('rcr-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'rcr-panel';
    panel.style.cssText = `
      position:fixed;
      right:16px;
      bottom:16px;
      z-index:99999999;
      width:330px;
      background:#111827;
      color:white;
      border-radius:18px;
      padding:16px;
      font-family:Arial,sans-serif;
      box-shadow:0 18px 40px rgba(0,0,0,.4);
      display:${config.panelVisible ? 'block' : 'none'};
    `;

    panel.innerHTML = `
      <div style="font-size:18px;font-weight:900;margin-bottom:2px;">🔥 Relay Contract Refresher</div>
      <div style="font-size:12px;color:#9ca3af;margin-bottom:12px;">by Relay Tools • v1.2</div>

      <div style="display:flex;gap:10px;">
        <label style="flex:1;">Min sec
          <input id="rcr-min" type="number" value="${config.minRefresh}" style="width:100%;margin-top:4px;padding:8px;border-radius:10px;border:0;">
        </label>
        <label style="flex:1;">Max sec
          <input id="rcr-max" type="number" value="${config.maxRefresh}" style="width:100%;margin-top:4px;padding:8px;border-radius:10px;border:0;">
        </label>
      </div>

      <label style="display:block;margin-top:10px;"><input id="rcr-autostop" type="checkbox" ${config.autoStop ? 'checked' : ''}> Auto stop after change</label>
      <label style="display:block;margin-top:8px;"><input id="rcr-sound" type="checkbox" ${config.sound ? 'checked' : ''}> Sound alert</label>
      <label style="display:block;margin-top:8px;"><input id="rcr-telegram" type="checkbox" ${config.telegram ? 'checked' : ''}> Telegram alerts</label>

      <div style="display:flex;gap:8px;margin-top:12px;">
        <button id="rcr-stop" style="flex:1;padding:12px;background:#dc2626;color:white;border:0;border-radius:12px;font-weight:900;cursor:pointer;">STOP</button>
        <button id="rcr-start" style="flex:1;padding:12px;background:#22c55e;color:white;border:0;border-radius:12px;font-weight:900;cursor:pointer;">START</button>
      </div>

      <button id="rcr-test" style="width:100%;margin-top:10px;padding:12px;background:#7c3aed;color:white;border:0;border-radius:12px;font-weight:900;cursor:pointer;">TEST ALERT 🔥</button>
      <button id="rcr-baseline" style="width:100%;margin-top:10px;padding:10px;background:#374151;color:white;border:0;border-radius:12px;font-weight:900;cursor:pointer;">RESET BASELINE</button>

      <div id="rcr-license" style="margin-top:12px;background:#0b1220;padding:10px;border-radius:12px;font-weight:900;color:#fca5a5;">License check...</div>
      <div id="rcr-countdown" style="margin-top:10px;background:#1f2937;padding:12px;border-radius:12px;font-weight:900;">Loading...</div>
      <div id="rcr-status" style="margin-top:10px;color:#d1d5db;font-size:13px;">Starting...</div>
    `;

    document.body.appendChild(panel);
    updateLicenseBadge();

    document.getElementById('rcr-stop').onclick = () => stopSystem('SYSTEM STOPPED');
    document.getElementById('rcr-start').onclick = startSystem;
    document.getElementById('rcr-test').onclick = () => {
      beep();
      flashTitle();
      setTimeout(stopFlash, 5000);
      sendTelegram('✅ Relay Contract Refresher test alert');
      setStatus('TEST ALERT SENT');
    };
    document.getElementById('rcr-baseline').onclick = autoBaseline;
    ['rcr-min', 'rcr-max', 'rcr-autostop', 'rcr-sound', 'rcr-telegram'].forEach(id => {
      document.getElementById(id).addEventListener('change', saveRefreshSettings);
    });
  }

  async function updateLicenseBadge() {
    const badge = document.getElementById('rcr-license');
    if (!badge) return;
    const data = await chromeGetSync(['licenseValid', 'licenseExpires']);
    const active = data.licenseValid && data.licenseExpires && new Date(data.licenseExpires).getTime() > Date.now();
    if (active) {
      badge.textContent = `License ACTIVE • Expires ${new Date(data.licenseExpires).toLocaleDateString()}`;
      badge.style.color = '#86efac';
    } else {
      badge.textContent = 'License REQUIRED';
      badge.style.color = '#fca5a5';
    }
  }

  function listenForPopupMessages() {
    chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
      if (!message || !message.type) return;
      updateLicenseBadge();
      if (message.type === 'RCR_START') await startSystem();
      if (message.type === 'RCR_STOP') stopSystem('SYSTEM STOPPED FROM POPUP');
      if (message.type === 'RCR_TEST') {
        beep();
        flashTitle();
        setTimeout(stopFlash, 5000);
        sendTelegram('✅ Relay Contract Refresher test alert');
        setStatus('TEST ALERT SENT');
      }
      if (message.type === 'RCR_BASELINE') autoBaseline();
      if (message.type === 'RCR_TOGGLE_PANEL') {
        config.panelVisible = !config.panelVisible;
        saveConfig();
        const panel = document.getElementById('rcr-panel');
        if (panel) panel.style.display = config.panelVisible ? 'block' : 'none';
      }
      sendResponse({ ok: true });
    });
  }

  init();
})();
