(function () {
  'use strict';

  if (window.__relayContractRefresherLoaded) return;
  window.__relayContractRefresherLoaded = true;

  const CONFIG_KEY = 'rcr_config_v150';
  const LEGACY_CONFIG_KEY = 'rcr_config_v130';
  const STATE_KEY = 'rcr_state_v130';

  const defaultConfig = {
    enabled: true,
    autoStop: true,
    sound: true,
    telegram: true,
    minRefresh: 15,
    maxRefresh: 25,
    panelVisible: true
  };

  let config = { ...defaultConfig };
  let countdownTimer = null;
  let scanTimer = null;
  let flashInterval = null;
  let originalTitle = document.title;

  async function init() {
    await loadConfig();
    createPanel();

    if (config.enabled && await licenseIsActive()) {
      setTimeout(autoBaseline, 1500);
      setTimeout(scanContracts, 3000);
      scanTimer = setInterval(scanContracts, 3000);
      startCountdown();
    } else if (config.enabled) {
      config.enabled = false;
      setStatus('License required. Activate from extension popup.');
    }

    listenForPopupMessages();
    updateButtons();
    setStatus(config.enabled ? 'System ready' : 'System stopped');
    checkLicenseOnLoad();
  }

  function chromeGet(keys) {
    return new Promise(resolve => chrome.storage.sync.get(keys, resolve));
  }

  function chromeSet(data) {
    return new Promise(resolve => chrome.storage.sync.set(data, resolve));
  }

  async function loadConfig() {
    const saved = await chromeGet([CONFIG_KEY, LEGACY_CONFIG_KEY]);
    config = { ...defaultConfig, ...(saved[CONFIG_KEY] || saved[LEGACY_CONFIG_KEY] || {}) };
  }

  async function saveConfig() {
    await chromeSet({ [CONFIG_KEY]: config, [LEGACY_CONFIG_KEY]: config });
    await chromeSet({
      minRefresh: config.minRefresh,
      maxRefresh: config.maxRefresh,
      autoStop: config.autoStop,
      soundEnabled: config.sound,
      telegramEnabled: config.telegram
    });
  }


  function chromeGetSync(keys) {
    return new Promise(resolve => chrome.storage.sync.get(keys, resolve));
  }

  async function licenseIsActive() {
    const data = await chromeGetSync(['licenseValid', 'licenseExpires']);
    if (!data.licenseValid || !data.licenseExpires) return false;
    return new Date(data.licenseExpires).getTime() > Date.now();
  }

  async function checkLicenseOnLoad() {
    if (!(await licenseIsActive())) {
      stopSystem('LICENSE REQUIRED');
      chrome.storage.local.set({ rcrLastStatus: 'License required. Activate from extension popup.' });
    }
  }

  function loadState() {
    try {
      return JSON.parse(localStorage.getItem(STATE_KEY) || '{}');
    } catch {
      return {};
    }
  }

  function saveState(data) {
    localStorage.setItem(STATE_KEY, JSON.stringify(data));
  }

  function sendTelegram(msg) {
    if (!config.telegram) return;
    try {
      chrome.runtime.sendMessage({ type: 'SEND_TELEGRAM', text: msg });
    } catch {}
  }

  function beep() {
    if (!config.sound) return;
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.value = 1700;
      gain.gain.value = 0.35;
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      setTimeout(() => {
        osc.stop();
        ctx.close();
      }, 900);
    } catch {}
  }

  function flashTitle() {
    if (flashInterval) return;
    flashInterval = setInterval(() => {
      document.title = document.title.includes('🔥') ? originalTitle : '🔥 PRICE / CONTRACT CHANGE';
    }, 700);
  }

  function stopFlash() {
    if (flashInterval) clearInterval(flashInterval);
    flashInterval = null;
    document.title = originalTitle;
  }

  function clickRelayRefreshButton() {
    const svgPath = [...document.querySelectorAll('svg path')]
      .find(p => (p.getAttribute('d') || '').includes('M20.128'));

    if (!svgPath) {
      setStatus('Refresh button not found.');
      return false;
    }

    const svg = svgPath.closest('svg');
    const target = svg.closest('button') || svg.closest('[role="button"]') || svg.parentElement;

    if (!target) {
      setStatus('Refresh target not found.');
      return false;
    }

    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(type => {
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });

    setStatus('Clicked Relay refresh button.');
    return true;
  }


  function getResultsCount() {
    const text = (document.body.innerText || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[–—]/g, '-')
      .replace(/\s+/g, ' ')
      .trim();

    let match = text.match(/Showing\s+\d+\s*-\s*\d+\s+of\s+(\d+)\s+results/i);
    if (match) return parseInt(match[1], 10);

    match = text.match(/\bof\s+(\d+)\s+results\b/i);
    if (match) return parseInt(match[1], 10);

    match = text.match(/\bof\s+(\d+)\s+result\b/i);
    if (match) return parseInt(match[1], 10);

    return null;
  }

  function getRows() {
    const all = [...document.querySelectorAll('div, tr, section, article')];
    const rows = all.filter(el => {
      const text = el.innerText || '';
      return (
        text.includes('£') &&
        text.includes('UK') &&
        text.length > 40 &&
        text.length < 1600 &&
        !text.includes('Relay Contract Refresher') &&
        !text.includes('SYSTEM STOPPED')
      );
    });
    return uniqueRows(rows.map(getBestRowContainer).filter(Boolean));
  }

  function getBestRowContainer(el) {
    let current = el;
    let best = el;

    for (let i = 0; i < 7 && current && current.parentElement; i++) {
      const parent = current.parentElement;
      const text = parent.innerText || '';
      const rect = parent.getBoundingClientRect();
      const looksLikeFullRow =
        text.includes('£') &&
        text.includes('UK') &&
        rect.width > window.innerWidth * 0.65 &&
        rect.height > 45 &&
        rect.height < 260 &&
        text.length < 2500;

      if (looksLikeFullRow) best = parent;
      current = parent;
    }

    return best;
  }

  function uniqueRows(rows) {
    const seen = new Set();
    return rows.filter(row => {
      const sig = getSignature(row);
      if (seen.has(sig)) return false;
      seen.add(sig);
      return true;
    });
  }

  function getSignature(row) {
    return row.innerText.replace(/\s+/g, ' ').trim().slice(0, 900);
  }

  function extractPrice(text) {
    const matches = [...text.matchAll(/£\s?([\d,]+(?:\.\d{1,2})?)/g)];
    if (!matches.length) return null;
    return Number(matches[0][1].replace(/,/g, ''));
  }

  function getStableKey(row) {
    return row.innerText
      .replace(/£\s?[\d,]+(?:\.\d{1,2})?/g, '£PRICE')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 650);
  }

  function getRowData() {
    return getRows().map(row => {
      const text = row.innerText || '';
      return { row, sig: getSignature(row), key: getStableKey(row), price: extractPrice(text), text };
    });
  }

  function setStatus(text) {
    const el = document.getElementById('rcr-status');
    if (el) el.textContent = text;
    updateTrackedCount();
    chrome.storage.local.set({ rcrLastStatus: text, rcrLastSeen: new Date().toLocaleTimeString() });
  }

  function clearVisualState() {
    stopFlash();

    document.querySelectorAll('.rcr-price-diff, .rcr-new-badge, .rcr-price-badge, .rcr-badge').forEach(el => el.remove());

    getRows().forEach(row => {
      row.classList.remove('rcr-new', 'rcr-changed', 'rcr-price-up', 'rcr-price-down', 'rcr-removed');
      row.style.removeProperty('background');
      row.style.removeProperty('background-color');
      row.style.removeProperty('box-shadow');
      row.style.removeProperty('outline');
      row.style.removeProperty('position');
      row.style.removeProperty('border');

      row.querySelectorAll('*').forEach(child => {
        child.style.removeProperty('background');
        child.style.removeProperty('background-color');
      });
    });
  }

  function buildCleanState() {
    const data = getRowData();
    return {
      ready: true,
      count: getResultsCount(),
      rows: data.map(x => x.sig),
      items: data.map(x => ({ key: x.key, sig: x.sig, price: x.price })),
      resetAt: new Date().toISOString()
    };
  }

  function resetBaseline() {
    clearVisualState();
    const cleanState = buildCleanState();
    saveState(cleanState);
    chrome.storage.local.set({
      rcrCountdown: 'Baseline reset. Current page saved as clean.',
      rcrLastStatus: 'Baseline reset. Current page saved as clean.',
      rcrLastSeen: new Date().toLocaleTimeString()
    });
    setStatus('Baseline reset. Current page saved as clean.');
    addPremiumEvent('Baseline reset', 'Current page saved as clean', 'blue');
    showPremiumToast('Baseline reset', 'Current page saved as clean.', 'blue');
  }

  function autoBaseline() {
    const data = getRowData();
    saveState({
      ready: true,
      count: getResultsCount(),
      rows: data.map(x => x.sig),
      items: data.map(x => ({ key: x.key, sig: x.sig, price: x.price }))
    });
    setStatus('Baseline ready');
  }


  function clearVisualHighlights() {
    document.querySelectorAll('.rcr-price-diff').forEach(el => el.remove());

    document.querySelectorAll('.rcr-new, .rcr-price-up, .rcr-price-down, .rcr-changed, .rcr-removed')
      .forEach(row => {
        row.classList.remove('rcr-new', 'rcr-price-up', 'rcr-price-down', 'rcr-changed', 'rcr-removed');
        row.style.removeProperty('background');
        row.style.removeProperty('background-color');
        row.style.removeProperty('box-shadow');
        row.style.removeProperty('outline');
      });
  }

  function paintRow(row, type, diffText) {
    const isDown = type === 'down';
    const isNew = type === 'new' || diffText === 'NEW';

    const theme = isNew
      ? {
          main: '#2563eb',
          soft: 'rgba(219,234,254,0.92)',
          soft2: 'rgba(191,219,254,0.72)',
          badge: '#2563eb',
          text: 'NEW'
        }
      : isDown
        ? {
            main: '#ef4444',
            soft: 'rgba(254,226,226,0.95)',
            soft2: 'rgba(252,165,165,0.62)',
            badge: '#dc2626',
            text: diffText
          }
        : {
            main: '#16a34a',
            soft: 'rgba(220,252,231,0.95)',
            soft2: 'rgba(134,239,172,0.58)',
            badge: '#059669',
            text: diffText
          };

    row.classList.remove('rcr-new', 'rcr-changed', 'rcr-price-up', 'rcr-price-down', 'rcr-removed');
    row.classList.add(isNew ? 'rcr-new' : isDown ? 'rcr-price-down' : 'rcr-price-up');

    row.style.setProperty(
      'background',
      `linear-gradient(90deg, ${theme.soft2} 0%, ${theme.soft} 18%, ${theme.soft} 82%, rgba(255,255,255,.98) 100%)`,
      'important'
    );
    row.style.setProperty('background-color', theme.soft, 'important');
    row.style.setProperty('box-shadow', `inset 6px 0 0 ${theme.main}, 0 10px 30px rgba(15,23,42,.10), 0 0 26px ${theme.soft2}`, 'important');
    row.style.setProperty('outline', '0', 'important');
    row.style.setProperty('border-radius', '12px', 'important');
    row.style.setProperty('position', 'relative', 'important');
    row.style.setProperty('overflow', 'visible', 'important');

    row.querySelectorAll('*').forEach(child => {
      const text = child.innerText || '';
      const isButton = text.trim() === 'Accept' || child.tagName === 'BUTTON' || child.querySelector?.('button');
      const isPriceArea = /£\s?[\d,]+/.test(text) && text.length < 180;

      if (isButton || isPriceArea) return;

      child.style.setProperty('background', 'transparent', 'important');
      child.style.setProperty('background-color', 'transparent', 'important');
    });

    row.querySelectorAll('.rcr-price-diff').forEach(el => el.remove());

    if (theme.text) {
      const badge = document.createElement('div');
      badge.className = 'rcr-price-diff';
      badge.textContent = theme.text;
      badge.style.cssText = `
        position:absolute;
        right:360px;
        top:14px;
        z-index:99999;
        background:${theme.badge};
        color:white;
        padding:7px 12px;
        border-radius:999px;
        font-weight:950;
        font-size:13px;
        letter-spacing:.01em;
        box-shadow:0 8px 20px rgba(15,23,42,.28);
        pointer-events:none;
        border:1px solid rgba(255,255,255,.32);
      `;
      row.appendChild(badge);
    }

    try { row.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch {}
  }

  async function stopSystem(reason = 'SYSTEM STOPPED') {
    config.enabled = false;
    await saveConfig();
    if (scanTimer) clearInterval(scanTimer);
    if (countdownTimer) clearInterval(countdownTimer);
    stopFlash();
    setStatus(reason);
    const countdown = document.getElementById('rcr-countdown');
    if (countdown) {
      countdown.textContent = reason;
      countdown.style.color = '#ef4444';
    }
    updateButtons();
  }

  async function startSystem() {
    if (!(await licenseIsActive())) {
      config.enabled = false;
      await saveConfig();
      setStatus('License required. Activate from extension popup.');
      updateButtons();
      return;
    }

    config.enabled = true;
    await saveConfig();
    autoBaseline();
    if (scanTimer) clearInterval(scanTimer);
    scanTimer = setInterval(scanContracts, 3000);
    startCountdown();
    setStatus('SYSTEM STARTED');
    updateButtons();
  }

  function updateButtons() {
    const stopBtn = document.getElementById('rcr-stop');
    const startBtn = document.getElementById('rcr-start');
    if (!stopBtn || !startBtn) return;
    stopBtn.disabled = !config.enabled;
    startBtn.disabled = config.enabled;
    stopBtn.style.opacity = config.enabled ? '1' : '.45';
    startBtn.style.opacity = config.enabled ? '.45' : '1';
  }

  async function saveRefreshSettings() {
    config.minRefresh = Number(document.getElementById('rcr-min').value) || 15;
    config.maxRefresh = Number(document.getElementById('rcr-max').value) || 25;
    config.autoStop = document.getElementById('rcr-autostop').checked;
    config.sound = document.getElementById('rcr-sound').checked;
    config.telegram = document.getElementById('rcr-telegram').checked;

    if (config.maxRefresh <= config.minRefresh) config.maxRefresh = config.minRefresh + 5;
    await saveConfig();
    startCountdown();
  }

  function scanContracts() {
    if (!config.enabled) return;

    const currentData = getRowData();
    const currentRows = currentData.map(x => x.sig);
    const currentCount = getResultsCount();
    const oldState = loadState();

    if (!oldState.ready) {
      autoBaseline();
      return;
    }

    const oldRows = oldState.rows || [];
    const oldItems = oldState.items || [];
    const oldByKey = new Map(oldItems.map(x => [x.key, x]));
    const changes = [];

    currentData.forEach(item => {
      const old = oldByKey.get(item.key);
      if (old && old.price !== null && item.price !== null && old.price !== item.price) {
        const diff = item.price - old.price;
        changes.push({ item, type: diff > 0 ? 'up' : 'down', oldPrice: old.price, newPrice: item.price, diff });
        return;
      }

      if (!oldRows.includes(item.sig)) {
        changes.push({ item, type: 'new', oldPrice: null, newPrice: item.price, diff: null });
      }
    });

    const countChanged = currentCount !== oldState.count;

    if (changes.length > 0 || countChanged) {
      saveState({
        ready: true,
        count: currentCount,
        rows: currentRows,
        items: currentData.map(x => ({ key: x.key, sig: x.sig, price: x.price }))
      });

      const telegramLines = [];
      changes.forEach(change => {
        let label = '🟢 NEW CONTRACT';
        if (change.type === 'up') {
          label = `🟢 PRICE UP +£${Math.abs(change.diff).toLocaleString()}`;
          paintRow(change.item.row, 'up', `+£${Math.abs(change.diff).toLocaleString()}`);
          addPremiumEvent(`+£${Math.abs(change.diff).toLocaleString()} Price Up`, change.item.text.split('\n').slice(0, 2).join(' • '), 'green');
          showPremiumToast(`+£${Math.abs(change.diff).toLocaleString()} Price Up`, change.item.text.split('\n').slice(0, 3).join(' • '), 'green');
        } else if (change.type === 'down') {
          label = `🔴 PRICE DOWN -£${Math.abs(change.diff).toLocaleString()}`;
          paintRow(change.item.row, 'down', `-£${Math.abs(change.diff).toLocaleString()}`);
          addPremiumEvent(`-£${Math.abs(change.diff).toLocaleString()} Price Down`, change.item.text.split('\n').slice(0, 2).join(' • '), 'red');
          showPremiumToast(`-£${Math.abs(change.diff).toLocaleString()} Price Down`, change.item.text.split('\n').slice(0, 3).join(' • '), 'red');
        } else {
          paintRow(change.item.row, 'new', 'NEW');
          addPremiumEvent('New contract detected', change.item.text.split('\n').slice(0, 2).join(' • '), 'blue');
          showPremiumToast('New contract detected', change.item.text.split('\n').slice(0, 3).join(' • '), 'blue');
        }
        telegramLines.push(`${label}\n${change.item.text.split('\n').slice(0, 5).join(' | ')}`);
      });

      if (changes.length >= Math.max(3, Math.ceil(currentData.length * 0.45))) {
        addPremiumEvent('Global price event', `${changes.length} contracts changed together`, 'purple');
        showPremiumToast('Global price event detected', `${changes.length} contracts changed together.`, 'purple');
      }

      beep();
      flashTitle();
      setTimeout(stopFlash, 120000);

      sendTelegram(`🔥 RELAY CONTRACT REFRESHER\nResults: ${oldState.count} → ${currentCount}\nChanges: ${changes.length}\n\n${telegramLines.slice(0, 5).join('\n\n')}`);
      setStatus(`🔥 CHANGE DETECTED ${oldState.count} → ${currentCount} • ${changes.length} changes`);

      chrome.storage.local.get(['rcrStats'], data => {
        const stats = data.rcrStats || { detectedToday: 0, priceChangesToday: 0, date: new Date().toDateString() };
        if (stats.date !== new Date().toDateString()) {
          stats.detectedToday = 0;
          stats.priceChangesToday = 0;
          stats.date = new Date().toDateString();
        }
        stats.detectedToday += changes.filter(c => c.type === 'new').length;
        stats.priceChangesToday += changes.filter(c => c.type === 'up' || c.type === 'down').length;
        chrome.storage.local.set({ rcrStats: stats });
      });

      if (config.autoStop) stopSystem('🔥 AUTO STOPPED AFTER CHANGE');
      return;
    }

    setStatus(`No change • ${new Date().toLocaleTimeString()}`);
  }

  function startCountdown() {
    if (countdownTimer) clearInterval(countdownTimer);
    if (!config.enabled) return;

    const min = Math.max(5, config.minRefresh);
    const max = Math.max(min + 1, config.maxRefresh);
    let left = Math.floor(min + Math.random() * (max - min + 1));
    const el = document.getElementById('rcr-countdown');

    const tick = () => {
      if (!config.enabled) return;
      if (!el) return;
      el.textContent = `Click refresh in ${left}s • ${min}-${max}s`;
      updateMiniNext(el.textContent);
      chrome.storage.local.set({ rcrCountdown: el.textContent });
      if (left <= 0) {
        clickRelayRefreshButton();
        setTimeout(() => {
          scanContracts();
          startCountdown();
        }, 2500);
        return;
      }
      left--;
    };

    tick();
    countdownTimer = setInterval(tick, 1000);
  }

  function createPanel() {
    if (document.getElementById('rcr-panel')) return document.getElementById('rcr-panel');

    ensurePremiumStyles();

    const panel = document.createElement('div');
    panel.id = 'rcr-panel';
    panel.className = 'rcr-premium-panel rcr-live-only-panel';
    panel.style.display = config.panelVisible ? 'block' : 'none';

    panel.innerHTML = `
      <div class="rcr-orb rcr-orb-blue"></div>
      <div class="rcr-orb rcr-orb-purple"></div>

      <div class="rcr-premium-header" id="rcr-drag-handle">
        <div class="rcr-brand-row">
          <div class="rcr-logo-badge">⚡</div>
          <div>
            <div class="rcr-title">Relay Tools Pro</div>
            <div class="rcr-subtitle">Live control monitor</div>
          </div>
        </div>
        <div class="rcr-live-chip"><span></span> LIVE</div>
      </div>

      <div class="rcr-top-stats">
        <div class="rcr-stat-card">
          <div class="rcr-stat-label">Tracked</div>
          <div class="rcr-stat-value" id="rcr-tracked-count">--</div>
        </div>
        <div class="rcr-stat-card">
          <div class="rcr-stat-label">Changes</div>
          <div class="rcr-stat-value" id="rcr-change-count">0</div>
        </div>
        <div class="rcr-stat-card">
          <div class="rcr-stat-label">Next</div>
          <div class="rcr-stat-value" id="rcr-mini-next">--</div>
        </div>
      </div>

      <div class="rcr-action-grid">
        <button id="rcr-stop" class="rcr-btn rcr-btn-stop">STOP</button>
        <button id="rcr-start" class="rcr-btn rcr-btn-start">START</button>
      </div>

      <div id="rcr-license" class="rcr-license-card">License check...</div>

      <div class="rcr-countdown-card">
        <div id="rcr-countdown">Loading...</div>
        <div id="rcr-status">Starting...</div>
      </div>

      <div class="rcr-events-card">
        <div class="rcr-events-title">Live Events</div>
        <div id="rcr-events-list" class="rcr-events-list">
          <div class="rcr-empty-event">Waiting for contract activity...</div>
        </div>
      </div>

      <div class="rcr-footer-row">
        <button id="rcr-compact" class="rcr-mini-btn">Compact</button>
        <button id="rcr-close-soft" class="rcr-mini-btn">Hide</button>
      </div>
    `;

    document.body.appendChild(panel);
    restorePanelPosition(panel);
    makePanelDraggable(panel);
    updateLicenseBadge();

    document.getElementById('rcr-stop').onclick = () => stopSystem('SYSTEM STOPPED');
    document.getElementById('rcr-start').onclick = async () => {
      clearVisualHighlights?.();
      await resetBaseline(true);
      startSystem();
    };
    document.getElementById('rcr-compact').onclick = () => toggleCompactPanel(panel);
    document.getElementById('rcr-close-soft').onclick = () => {
      const existing = document.getElementById('rcr-restore-floating');

      if (existing) {
        existing.remove();
      }

      config.panelVisible = false;
      saveConfig();
      panel.style.display = 'none';

      const restoreBtn = document.createElement('button');
      restoreBtn.id = 'rcr-restore-floating';
      restoreBtn.innerHTML = '⚡ Relay Tools';
      restoreBtn.style.cssText = `
        position: fixed;
        right: 18px;
        bottom: 18px;
        z-index: 999999;
        border: 0;
        border-radius: 999px;
        padding: 12px 16px;
        font-weight: 900;
        cursor: pointer;
        color: white;
        background: linear-gradient(135deg,#2563eb,#7c3aed);
        box-shadow: 0 12px 30px rgba(37,99,235,.35);
      `;

      restoreBtn.onclick = () => {
        panel.style.display = 'block';
        config.panelVisible = true;
        saveConfig();
        restoreBtn.remove();
      };

      document.body.appendChild(restoreBtn);
    };

    return panel;
  }

  function ensurePremiumStyles() {
    if (document.getElementById('rcr-premium-style')) return;

    const style = document.createElement('style');
    style.id = 'rcr-premium-style';
    style.textContent = `
      #rcr-panel.rcr-premium-panel {
        position: fixed;
        right: 18px;
        bottom: 18px;
        width: 338px;
        z-index: 99999999;
        color: #fff;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
        background:
          radial-gradient(circle at top left, rgba(37,99,235,.28), transparent 36%),
          radial-gradient(circle at top right, rgba(124,58,237,.26), transparent 34%),
          rgba(7, 13, 28, .88);
        border: 1px solid rgba(255,255,255,.10);
        border-radius: 26px;
        padding: 14px;
        box-shadow:
          0 26px 70px rgba(0,0,0,.52),
          0 0 0 1px rgba(255,255,255,.04) inset,
          0 0 55px rgba(37,99,235,.18);
        backdrop-filter: blur(18px) saturate(145%);
        -webkit-backdrop-filter: blur(18px) saturate(145%);
        overflow: hidden;
        animation: rcrPanelIn .28s ease-out;
      }

      #rcr-panel * { box-sizing: border-box; }

      @keyframes rcrPanelIn {
        from { opacity: 0; transform: translateY(16px) scale(.98); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }

      #rcr-panel .rcr-orb {
        position: absolute;
        width: 130px;
        height: 130px;
        border-radius: 999px;
        filter: blur(36px);
        opacity: .38;
        pointer-events: none;
      }

      #rcr-panel .rcr-orb-blue {
        background: #2563eb;
        left: -48px;
        top: -44px;
      }

      #rcr-panel .rcr-orb-purple {
        background: #7c3aed;
        right: -52px;
        top: 28px;
      }

      #rcr-panel .rcr-premium-header {
        position: relative;
        display: flex;
        justify-content: space-between;
        align-items: center;
        cursor: move;
        margin-bottom: 12px;
      }

      #rcr-panel .rcr-brand-row {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      #rcr-panel .rcr-logo-badge {
        width: 36px;
        height: 36px;
        display: grid;
        place-items: center;
        border-radius: 14px;
        background: linear-gradient(135deg, rgba(37,99,235,.95), rgba(124,58,237,.95));
        box-shadow: 0 12px 30px rgba(37,99,235,.32);
        font-size: 18px;
      }

      #rcr-panel .rcr-title {
        font-size: 16px;
        line-height: 18px;
        font-weight: 950;
        letter-spacing: -.03em;
      }

      #rcr-panel .rcr-subtitle {
        font-size: 11px;
        color: #94a3b8;
        margin-top: 2px;
      }

      #rcr-panel .rcr-live-chip {
        display: flex;
        align-items: center;
        gap: 6px;
        border-radius: 999px;
        padding: 6px 9px;
        background: rgba(16,185,129,.14);
        border: 1px solid rgba(16,185,129,.28);
        color: #86efac;
        font-size: 10px;
        font-weight: 950;
      }

      #rcr-panel .rcr-live-chip span {
        width: 7px;
        height: 7px;
        border-radius: 999px;
        background: #34d399;
        box-shadow: 0 0 0 6px rgba(52,211,153,.12);
        animation: rcrPulse 1.5s infinite;
      }

      @keyframes rcrPulse {
        0% { transform: scale(.9); opacity: .8; }
        50% { transform: scale(1.22); opacity: 1; }
        100% { transform: scale(.9); opacity: .8; }
      }

      #rcr-panel .rcr-top-stats {
        position: relative;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        margin-bottom: 10px;
      }

      #rcr-panel .rcr-stat-card,
      #rcr-panel .rcr-license-card,
      #rcr-panel .rcr-countdown-card,
      #rcr-panel .rcr-events-card {
        background: rgba(15,23,42,.62);
        border: 1px solid rgba(255,255,255,.07);
        border-radius: 17px;
        box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
      }

      #rcr-panel .rcr-stat-card {
        padding: 9px 8px;
        text-align: center;
      }

      #rcr-panel .rcr-stat-label {
        font-size: 10px;
        color: #94a3b8;
        font-weight: 800;
      }

      #rcr-panel .rcr-stat-value {
        font-size: 15px;
        margin-top: 3px;
        font-weight: 950;
        color: #e0f2fe;
      }

      #rcr-panel .rcr-field-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 9px;
        margin-bottom: 10px;
      }

      #rcr-panel .rcr-field {
        display: block;
        font-size: 11px;
        font-weight: 850;
        color: #cbd5e1;
      }

      #rcr-panel .rcr-field input {
        margin-top: 5px;
        width: 100%;
        border: 1px solid rgba(255,255,255,.08);
        border-radius: 14px;
        padding: 10px;
        background: rgba(2,6,23,.64);
        color: white;
        outline: none;
        font-weight: 850;
      }

      #rcr-panel .rcr-field input:focus {
        border-color: rgba(96,165,250,.8);
        box-shadow: 0 0 0 3px rgba(37,99,235,.18);
      }

      #rcr-panel .rcr-toggle-stack {
        display: grid;
        gap: 8px;
        margin-bottom: 10px;
      }

      #rcr-panel .rcr-premium-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 12px;
        font-weight: 850;
        color: #dbeafe;
      }

      #rcr-panel .rcr-premium-toggle input {
        display: none;
      }

      #rcr-panel .rcr-premium-toggle i {
        width: 42px;
        height: 24px;
        border-radius: 999px;
        background: #334155;
        position: relative;
        transition: .18s ease;
        box-shadow: inset 0 0 0 1px rgba(255,255,255,.05);
      }

      #rcr-panel .rcr-premium-toggle i::after {
        content: "";
        position: absolute;
        width: 18px;
        height: 18px;
        left: 3px;
        top: 3px;
        border-radius: 999px;
        background: white;
        transition: .18s ease;
        box-shadow: 0 4px 10px rgba(0,0,0,.35);
      }

      #rcr-panel .rcr-premium-toggle input:checked + i {
        background: linear-gradient(135deg, #10b981, #22c55e);
      }

      #rcr-panel .rcr-premium-toggle input:checked + i::after {
        transform: translateX(18px);
      }

      #rcr-panel .rcr-action-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 9px;
        margin-bottom: 9px;
      }

      #rcr-panel .rcr-btn {
        width: 100%;
        border: 0;
        border-radius: 16px;
        padding: 11px 10px;
        color: white;
        font-weight: 950;
        cursor: pointer;
        transition: .18s ease;
        letter-spacing: .01em;
      }

      #rcr-panel .rcr-btn:hover {
        transform: translateY(-1px);
      }

      #rcr-panel .rcr-btn:disabled {
        opacity: .45;
        cursor: not-allowed;
        transform: none;
      }

      #rcr-panel .rcr-btn-stop {
        background: linear-gradient(135deg, #ef4444, #b91c1c);
        box-shadow: 0 12px 26px rgba(239,68,68,.22);
      }

      #rcr-panel .rcr-btn-start {
        background: linear-gradient(135deg, #16a34a, #047857);
        box-shadow: 0 12px 26px rgba(16,185,129,.2);
      }

      #rcr-panel .rcr-btn-primary {
        background: linear-gradient(135deg, #2563eb, #7c3aed);
        box-shadow: 0 14px 34px rgba(37,99,235,.28);
        margin-bottom: 9px;
      }

      #rcr-panel .rcr-btn-dark {
        background: rgba(51,65,85,.82);
        border: 1px solid rgba(255,255,255,.06);
        margin-bottom: 10px;
      }

      #rcr-panel .rcr-license-card {
        padding: 11px 12px;
        font-weight: 950;
        font-size: 12px;
        margin-bottom: 9px;
        color: #fca5a5;
      }

      #rcr-panel .rcr-countdown-card {
        padding: 11px 12px;
        margin-bottom: 9px;
      }

      #rcr-panel #rcr-countdown {
        font-weight: 950;
        font-size: 13px;
        color: #f8fafc;
      }

      #rcr-panel #rcr-status {
        margin-top: 5px;
        color: #94a3b8;
        font-size: 11px;
      }

      #rcr-panel .rcr-events-card {
        padding: 10px;
        margin-bottom: 9px;
      }

      #rcr-panel .rcr-events-title {
        font-size: 11px;
        color: #cbd5e1;
        font-weight: 950;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: .08em;
      }

      #rcr-panel .rcr-events-list {
        display: grid;
        gap: 6px;
        max-height: 94px;
        overflow: auto;
        padding-right: 2px;
      }

      #rcr-panel .rcr-events-list::-webkit-scrollbar {
        width: 4px;
      }

      #rcr-panel .rcr-events-list::-webkit-scrollbar-thumb {
        background: rgba(148,163,184,.35);
        border-radius: 999px;
      }

      #rcr-panel .rcr-event,
      #rcr-panel .rcr-empty-event {
        border-radius: 12px;
        padding: 8px;
        font-size: 11px;
        border: 1px solid rgba(255,255,255,.06);
        background: rgba(2,6,23,.38);
      }

      #rcr-panel .rcr-event-title {
        font-weight: 950;
      }

      #rcr-panel .rcr-event-meta {
        color: #94a3b8;
        margin-top: 2px;
      }

      #rcr-panel .rcr-event.green { background: rgba(16,185,129,.12); color: #86efac; border-color: rgba(16,185,129,.18); }
      #rcr-panel .rcr-event.red { background: rgba(239,68,68,.12); color: #fca5a5; border-color: rgba(239,68,68,.18); }
      #rcr-panel .rcr-event.blue { background: rgba(59,130,246,.12); color: #93c5fd; border-color: rgba(59,130,246,.18); }
      #rcr-panel .rcr-event.purple { background: rgba(124,58,237,.14); color: #c4b5fd; border-color: rgba(124,58,237,.2); }

      #rcr-panel .rcr-empty-event {
        color: #64748b;
        text-align: center;
      }

      #rcr-panel .rcr-footer-row {
        display: flex;
        gap: 8px;
      }

      #rcr-panel .rcr-mini-btn {
        flex: 1;
        background: rgba(15,23,42,.55);
        border: 1px solid rgba(255,255,255,.06);
        border-radius: 13px;
        color: #cbd5e1;
        padding: 8px;
        font-size: 11px;
        font-weight: 950;
        cursor: pointer;
      }

      #rcr-panel.rcr-compact {
        width: 220px;
        padding: 10px;
      }

      #rcr-panel.rcr-compact .rcr-top-stats,
      #rcr-panel.rcr-compact .rcr-field-grid,
      #rcr-panel.rcr-compact .rcr-toggle-stack,
      #rcr-panel.rcr-compact .rcr-action-grid,
      #rcr-panel.rcr-compact #rcr-test,
      #rcr-panel.rcr-compact #rcr-baseline,
      #rcr-panel.rcr-compact .rcr-license-card,
      #rcr-panel.rcr-compact .rcr-events-card {
        display: none;
      }

      #rcr-panel.rcr-compact .rcr-footer-row {
        display: flex;
        margin-top: 8px;
      }

      #rcr-panel.rcr-compact #rcr-close-soft {
        display: none;
      }

      #rcr-panel.rcr-compact #rcr-compact {
        flex: 1;
        background: linear-gradient(135deg,#2563eb,#7c3aed);
        color: white;
      }

      #rcr-panel.rcr-compact .rcr-premium-header {
        margin-bottom: 8px;
      }

      #rcr-panel.rcr-compact .rcr-countdown-card {
        margin: 0;
      }


      #rcr-panel.rcr-live-only-panel .rcr-btn-dark {
        margin-bottom: 10px;
      }

      #rcr-panel.rcr-live-only-panel {
        width: 318px;
      }

      #rcr-panel.rcr-compact .rcr-action-grid,
      #rcr-panel.rcr-compact #rcr-baseline {
        display: none;
      }

      .rcr-toast-stack {
        position: fixed;
        right: 370px;
        bottom: 22px;
        z-index: 999999999;
        display: grid;
        gap: 10px;
        pointer-events: none;
      }

      .rcr-toast {
        min-width: 250px;
        max-width: 330px;
        padding: 13px 14px;
        border-radius: 18px;
        color: white;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
        background: rgba(7, 13, 28, .92);
        border: 1px solid rgba(255,255,255,.10);
        box-shadow: 0 18px 48px rgba(0,0,0,.48), 0 0 30px rgba(37,99,235,.15);
        backdrop-filter: blur(16px);
        animation: rcrToastIn .25s ease-out;
        overflow: hidden;
      }

      .rcr-toast::before {
        content: "";
        position: absolute;
        inset: 0 0 auto 0;
        height: 3px;
        background: linear-gradient(90deg, #2563eb, #7c3aed);
      }

      .rcr-toast.green::before { background: linear-gradient(90deg, #10b981, #22c55e); }
      .rcr-toast.red::before { background: linear-gradient(90deg, #ef4444, #f97316); }
      .rcr-toast.blue::before { background: linear-gradient(90deg, #3b82f6, #06b6d4); }
      .rcr-toast.purple::before { background: linear-gradient(90deg, #7c3aed, #ec4899); }

      .rcr-toast-title {
        font-size: 13px;
        font-weight: 950;
      }

      .rcr-toast-body {
        margin-top: 4px;
        font-size: 12px;
        color: #cbd5e1;
        line-height: 1.35;
      }

      @keyframes rcrToastIn {
        from { opacity: 0; transform: translateY(12px) scale(.98); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }

      @keyframes rcrToastOut {
        from { opacity: 1; transform: translateY(0) scale(1); }
        to { opacity: 0; transform: translateY(12px) scale(.98); }
      }
    `;
    document.head.appendChild(style);
  }

  function showPremiumToast(title, body, type = 'blue') {
    let stack = document.querySelector('.rcr-toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'rcr-toast-stack';
      document.body.appendChild(stack);
    }

    const toast = document.createElement('div');
    toast.className = `rcr-toast ${type}`;
    toast.innerHTML = `
      <div class="rcr-toast-title">${escapeHtml(title)}</div>
      <div class="rcr-toast-body">${escapeHtml(body)}</div>
    `;

    stack.prepend(toast);

    setTimeout(() => {
      toast.style.animation = 'rcrToastOut .25s ease-in forwards';
      setTimeout(() => toast.remove(), 260);
    }, 5200);
  }

  function addPremiumEvent(title, meta, type = 'blue') {
    const list = document.getElementById('rcr-events-list');
    if (!list) return;

    const empty = list.querySelector('.rcr-empty-event');
    if (empty) empty.remove();

    const item = document.createElement('div');
    item.className = `rcr-event ${type}`;
    item.innerHTML = `
      <div class="rcr-event-title">${escapeHtml(title)}</div>
      <div class="rcr-event-meta">${new Date().toLocaleTimeString()} • ${escapeHtml(meta || '')}</div>
    `;

    list.prepend(item);

    while (list.children.length > 8) {
      list.removeChild(list.lastElementChild);
    }

    chrome.storage.local.get(['rcrPremiumEvents'], data => {
      const events = data.rcrPremiumEvents || [];
      events.unshift({ title, meta, type, time: new Date().toISOString() });
      chrome.storage.local.set({ rcrPremiumEvents: events.slice(0, 20) });
    });

    updateChangeCounter();
  }

  function updateChangeCounter() {
    chrome.storage.local.get(['rcrPremiumEvents'], data => {
      const count = (data.rcrPremiumEvents || []).length;
      const el = document.getElementById('rcr-change-count');
      if (el) el.textContent = String(count);
      try {
        chrome.runtime.sendMessage({ type: 'RCR_SET_BADGE', text: count ? String(Math.min(count, 99)) : '' });
      } catch {}
    });
  }

  function updateTrackedCount() {
    const el = document.getElementById('rcr-tracked-count');
    if (!el) return;

    const officialTotal = getResultsCount();

    if (officialTotal !== null && !Number.isNaN(officialTotal)) {
      el.textContent = String(officialTotal);
      return;
    }

    const detectedRows = getRowData().length || 0;
    el.textContent = String(detectedRows);
  }

  function updateMiniNext(text) {
    const el = document.getElementById('rcr-mini-next');
    if (!el) return;
    const match = String(text || '').match(/(\d+)s/);
    el.textContent = match ? `${match[1]}s` : '--';
  }

  function toggleCompactPanel(panel) {
    panel.classList.toggle('rcr-compact');
    const btn = document.getElementById('rcr-compact');
    if (btn) btn.textContent = panel.classList.contains('rcr-compact') ? 'Expand' : 'Compact';
  }

  function makePanelDraggable(panel) {
    const handle = panel.querySelector('#rcr-drag-handle');
    if (!handle) return;

    let dragging = false;
    let startX = 0;
    let startY = 0;
    let startRight = 0;
    let startBottom = 0;

    handle.addEventListener('mousedown', e => {
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = panel.getBoundingClientRect();
      startRight = window.innerWidth - rect.right;
      startBottom = window.innerHeight - rect.bottom;
      document.body.style.userSelect = 'none';
    });

    window.addEventListener('mousemove', e => {
      if (!dragging) return;
      const newRight = Math.max(8, startRight - (e.clientX - startX));
      const newBottom = Math.max(8, startBottom - (e.clientY - startY));
      panel.style.right = `${newRight}px`;
      panel.style.bottom = `${newBottom}px`;
      panel.style.left = 'auto';
      panel.style.top = 'auto';
    });

    window.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false;
      document.body.style.userSelect = '';
      chrome.storage.local.set({
        rcrPanelPosition: {
          right: panel.style.right,
          bottom: panel.style.bottom
        }
      });
    });
  }

  function restorePanelPosition(panel) {
    chrome.storage.local.get(['rcrPanelPosition'], data => {
      const pos = data.rcrPanelPosition;
      if (!pos) return;
      if (pos.right) panel.style.right = pos.right;
      if (pos.bottom) panel.style.bottom = pos.bottom;
    });
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  async function updateLicenseBadge() {
    const badge = document.getElementById('rcr-license');
    if (!badge) return;
    const data = await chromeGetSync(['licenseValid', 'licenseExpires']);
    const active = data.licenseValid && data.licenseExpires && new Date(data.licenseExpires).getTime() > Date.now();
    if (active) {
      badge.textContent = `License ACTIVE • Expires ${new Date(data.licenseExpires).toLocaleDateString()}`;
      badge.style.color = '#86efac';
    } else {
      badge.textContent = 'License REQUIRED';
      badge.style.color = '#fca5a5';
    }
  }

  function listenForPopupMessages() {
    chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
      if (!message || !message.type) return;
      updateLicenseBadge();
      if (message.type === 'RCR_START') await startSystem();
      if (message.type === 'RCR_STOP') stopSystem('SYSTEM STOPPED FROM POPUP');
      if (message.type === 'RCR_TEST') {
        beep();
        flashTitle();
        setTimeout(stopFlash, 5000);
        sendTelegram('✅ Relay Contract Refresher test alert');
        setStatus('TEST ALERT SENT');
      }
      if (message.type === 'RCR_BASELINE') resetBaseline();

      if (message.type === 'RCR_EMAIL_TEST') {
        showPremiumToast(
          'Email Notifications Ready',
          `Test notification configured for ${message.email}`,
          'purple'
        );

        addPremiumEvent(
          'Email notification test',
          message.email,
          'purple'
        );

        sendResponse({ ok: true });
        return;
      }

      if (message.type === 'RCR_TOGGLE_PANEL') {
        config.panelVisible = !config.panelVisible;
        await saveConfig();
        const panel = document.getElementById('rcr-panel') || createPanel();
        const livePanel = document.getElementById('rcr-panel');
        if (livePanel) {
          livePanel.style.display = config.panelVisible ? 'block' : 'none';
        }
        setStatus(config.panelVisible ? 'Floating monitor panel shown' : 'Floating monitor panel hidden');
        sendResponse({ ok: true, panelVisible: config.panelVisible });
        return;
      }
      sendResponse({ ok: true });
    });
  }

  init();
})();
