const CONFIG_KEY = 'rcr_config_v150';
const CURRENT_VERSION = '3.6.5';

const defaults = {
  minRefresh: 15,
  maxRefresh: 25,
  autoStop: true,
  soundEnabled: true,
  telegramEnabled: true,
  telegramBotToken: '',
  telegramChatId: '',
  licenseEmail: '',
  licenseKey: '',
  licenseValid: false,
  licenseStatus: 'inactive',
  licenseExpires: '',
    licensePlan: '',
    licenseLoginSource: '',
  licenseApiUrl: 'https://relay-license-server.onrender.com/validate-license'
};

function $(id) { return document.getElementById(id); }

let userIsTyping = false;
let typingTimer = null;
let initialLoaded = false;

const editableIds = [
  'minRefresh',
  'maxRefresh',
  'telegramBotToken',
  'telegramChatId',
  'licenseEmail',
  'licenseKey',
  'licenseApiUrl'
];

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendToContent(type) {
  let tab = await getActiveTab();

  const isRelayTab = tab && tab.url && (
    tab.url.startsWith('https://relay.amazon.co.uk/contracts') ||
    tab.url.startsWith('https://relay.amazon.com/contracts')
  );

  if (!isRelayTab) {
    const relayTabs = await chrome.tabs.query({
      url: [
        'https://relay.amazon.co.uk/contracts*',
        'https://relay.amazon.com/contracts*'
      ]
    });

    tab = relayTabs && relayTabs.length ? relayTabs[0] : null;
  }

  if (!tab || !tab.id) {
    const saved = $('saved');
    if (saved) saved.textContent = 'Open Amazon Relay contracts page first.';
    return;
  }

  chrome.tabs.sendMessage(tab.id, { type }, (response) => {
    const saved = $('saved');

    if (chrome.runtime.lastError) {
      if (saved) saved.textContent = 'Refresh Amazon Relay contracts page once, then try again.';
      return;
    }

    const labels = {
      RCR_START: 'Monitoring started on Amazon Relay.',
      RCR_STOP: 'Monitoring stopped on Amazon Relay.',
      RCR_TEST: 'Test alert sent to Amazon Relay monitor.',
      RCR_BASELINE: 'Baseline reset on Amazon Relay.',
      RCR_TOGGLE_PANEL: 'Floating monitor toggled on Amazon Relay.'
    };

    if (saved) {
      saved.textContent = labels[type] || 'Command sent to Amazon Relay.';
      setTimeout(() => { saved.textContent = ''; }, 2800);
    }

    refreshStatusOnly();
  });
}

function isLicenseActive(data) {
  if (!data.licenseValid) return false;
  if (!data.licenseExpires) return false;
  return new Date(data.licenseExpires).getTime() > Date.now();
}

function renderLicense(data) {
  const active = isLicenseActive(data);
  const status = $('licenseStatus');
  const account = $('googleAccount');

  if (account) {
    account.textContent = data.licenseEmail ? `Signed in as ${data.licenseEmail}` : 'Not signed in';
  }

  if (active) {
    const expiry = new Date(data.licenseExpires).toLocaleDateString();
    const plan = data.licensePlan ? ` • ${String(data.licensePlan).toUpperCase()}` : '';
    status.textContent = `ACTIVE${plan} • Expires ${expiry}`;
    status.className = 'license-status good';
  } else if (data.licenseStatus === 'checking') {
    status.textContent = 'Checking license...';
    status.className = 'license-status warn';
  } else {
    const reason = data.licenseStatus || 'inactive';
    status.textContent = reason === 'expired' ? 'EXPIRED' : `NOT ACTIVATED • ${reason}`;
    status.className = 'license-status bad';
  }

  if ($('start')) $('start').disabled = !active;
  if ($('test')) $('test').disabled = !active;
}

function setFieldValue(id, value) {
  const el = $(id);
  if (!el) return;
  if (document.activeElement === el) return;
  el.value = value ?? '';
}

function setCheckboxValue(id, value) {
  const el = $(id);
  if (!el) return;
  if (document.activeElement === el) return;
  el.checked = !!value;
}

function loadInitialSettings() {
  chrome.storage.sync.get(Object.keys(defaults).concat(CONFIG_KEY), data => {
    const cfg = data[CONFIG_KEY] || {};

    setFieldValue('minRefresh', data.minRefresh ?? cfg.minRefresh ?? defaults.minRefresh);
    setFieldValue('maxRefresh', data.maxRefresh ?? cfg.maxRefresh ?? defaults.maxRefresh);
    setCheckboxValue('autoStop', data.autoStop ?? cfg.autoStop ?? defaults.autoStop);
    setCheckboxValue('soundEnabled', data.soundEnabled ?? cfg.sound ?? defaults.soundEnabled);
    setCheckboxValue('telegramEnabled', data.telegramEnabled ?? cfg.telegram ?? defaults.telegramEnabled);
    setFieldValue('telegramBotToken', data.telegramBotToken || '');
    setFieldValue('telegramChatId', data.telegramChatId || '');
    setFieldValue('licenseEmail', data.licenseEmail || '');
    setFieldValue('licenseKey', data.licenseKey || '');
    setFieldValue('licenseApiUrl', data.licenseApiUrl || defaults.licenseApiUrl);

    renderLicense(data);
    initialLoaded = true;
  });
}

function refreshStatusOnly() {
  chrome.storage.local.get(['rcrLastStatus', 'rcrCountdown'], data => {
    $('status').textContent = data.rcrLastStatus || 'Open Amazon Relay contracts page';
    $('countdown').textContent = data.rcrCountdown || 'No active timer yet';
  });

  chrome.storage.sync.get(['licenseValid', 'licenseStatus', 'licenseExpires', 'licenseEmail', 'licensePlan'], data => {
    renderLicense(data);
  });
}

function saveTypingDraft() {
  chrome.storage.local.set({
    rcrDraftEmail: $('licenseEmail').value,
    rcrDraftKey: $('licenseKey').value,
    rcrDraftBotToken: $('telegramBotToken').value,
    rcrDraftChatId: $('telegramChatId').value
  });
}

function markTyping() {
  userIsTyping = true;
  saveTypingDraft();
  clearTimeout(typingTimer);
  typingTimer = setTimeout(() => {
    userIsTyping = false;
  }, 1500);
}

function save() {
  let minRefresh = Number($('minRefresh').value) || 15;
  let maxRefresh = Number($('maxRefresh').value) || 25;
  if (maxRefresh <= minRefresh) maxRefresh = minRefresh + 5;

  const cfgForContent = {
    enabled: true,
    autoStop: $('autoStop').checked,
    sound: $('soundEnabled').checked,
    telegram: $('telegramEnabled').checked,
    minRefresh,
    maxRefresh,
    panelVisible: true
  };

  chrome.storage.sync.set({
    [CONFIG_KEY]: cfgForContent,
    minRefresh,
    maxRefresh,
    autoStop: $('autoStop').checked,
    soundEnabled: $('soundEnabled').checked,
    telegramEnabled: $('telegramEnabled').checked,
    telegramBotToken: $('telegramBotToken').value.trim(),
    telegramChatId: $('telegramChatId').value.trim(),
    licenseApiUrl: $('licenseApiUrl').value.trim() || defaults.licenseApiUrl
  }, () => {
    $('saved').textContent = 'Saved. Refresh Amazon Relay page once.';
    setTimeout(() => $('saved').textContent = '', 3000);
  });
}


function getGoogleOAuthClientId() {
  const manifest = chrome.runtime.getManifest();
  const clientId = manifest?.oauth2?.client_id || '';
  if (!clientId || clientId.includes('PASTE_GOOGLE_OAUTH_CLIENT_ID_HERE')) {
    return '';
  }
  return clientId;
}

function parseAccessTokenFromRedirect(redirectUrl) {
  const hash = new URL(redirectUrl).hash.replace(/^#/, '');
  const params = new URLSearchParams(hash);
  return params.get('access_token') || '';
}

async function fetchGoogleUserInfo(accessToken) {
  const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!response.ok) {
    throw new Error(`google_userinfo_${response.status}`);
  }

  const user = await response.json();
  const email = String(user.email || '').trim().toLowerCase();

  if (!email) {
    throw new Error('google_email_not_returned');
  }

  return {
    ok: true,
    email,
    name: user.name || '',
    picture: user.picture || '',
    sub: user.sub || ''
  };
}

function chooseGoogleAccount() {
  return new Promise((resolve) => {
    const clientId = getGoogleOAuthClientId();

    if (!clientId) {
      resolve({
        ok: false,
        error: 'google_oauth_client_id_missing'
      });
      return;
    }

    const redirectUri = chrome.identity.getRedirectURL();
    const authUrl = 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams({
      client_id: clientId,
      response_type: 'token',
      redirect_uri: redirectUri,
      scope: 'openid email profile',
      prompt: 'select_account',
      include_granted_scopes: 'true'
    }).toString();

    chrome.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true
    }, async (redirectUrl) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message || 'google_login_cancelled' });
        return;
      }

      if (!redirectUrl) {
        resolve({ ok: false, error: 'google_redirect_missing' });
        return;
      }

      try {
        const accessToken = parseAccessTokenFromRedirect(redirectUrl);

        if (!accessToken) {
          resolve({ ok: false, error: 'google_token_missing' });
          return;
        }

        const user = await fetchGoogleUserInfo(accessToken);
        resolve(user);
      } catch (error) {
        resolve({ ok: false, error: String(error.message || error) });
      }
    });
  });
}

async function getChromeGoogleEmailFallback() {
  return new Promise(resolve => {
    if (!chrome.identity || !chrome.identity.getProfileUserInfo) {
      resolve({ ok: false, error: 'chrome_identity_not_available' });
      return;
    }

    chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, info => {
      const email = String(info && info.email || '').trim().toLowerCase();
      if (!email) {
        resolve({ ok: false, error: 'Sign into Chrome with your Google account first.' });
        return;
      }
      resolve({ ok: true, email });
    });
  });
}

function verifyAndStoreLicense(email, key, source = 'manual') {
  const licenseApiUrl = $('licenseApiUrl')?.value?.trim() || defaults.licenseApiUrl;

  return new Promise(resolve => {
    chrome.storage.sync.set({
      licenseEmail: email,
      licenseKey: key,
      licenseApiUrl,
      licenseStatus: 'checking'
    }, () => renderLicense({ licenseEmail: email, licenseStatus: 'checking' }));

    chrome.runtime.sendMessage({ type: 'VERIFY_LICENSE', email, key }, response => {
      if (response && response.ok && response.active) {
        chrome.storage.sync.set({
          licenseEmail: email,
          licenseKey: key,
          licenseValid: true,
          licenseStatus: 'active',
          licensePlan: response.plan || '',
          licenseExpires: response.expiresAt,
          licenseLoginSource: source,
          licenseCheckedAt: new Date().toISOString()
        }, () => {
          $('saved').textContent = source === 'google' ? 'Google login successful.' : 'License activated.';
          refreshStatusOnly();
          resolve(true);
        });
      } else {
        const reason = response?.reason || response?.error || 'inactive';
        chrome.storage.sync.set({
          licenseEmail: email,
          licenseKey: source === 'google' ? '' : key,
          licenseValid: false,
          licenseStatus: reason,
          licensePlan: '',
          licenseExpires: '',
          licenseApiUrl: defaults.licenseApiUrl
        }, () => {
          $('saved').textContent = `License not active: ${reason}`;
          refreshStatusOnly();
          resolve(false);
        });
      }
    });
  });
}

async function loginWithGoogle() {
  $('saved').textContent = 'Opening Google account selector...';

  let profile = await chooseGoogleAccount();

  if (!profile.ok && profile.error === 'google_oauth_client_id_missing') {
    $('saved').textContent = 'Google OAuth Client ID missing. Add it in manifest.json.';
    renderLicense({ licenseStatus: 'google_oauth_client_id_missing' });
    return;
  }

  if (!profile.ok) {
    $('saved').textContent = profile.error || 'Google login failed.';
    renderLicense({ licenseStatus: 'google_login_failed' });
    return;
  }

  const email = profile.email;
  $('licenseEmail').value = email;
  $('googleAccount').textContent = `Signed in as ${email}`;
  $('saved').textContent = 'Checking license in Relay Tools Admin...';

  chrome.storage.sync.set({
    googleProfileName: profile.name || '',
    googleProfilePicture: profile.picture || '',
    googleProfileSub: profile.sub || ''
  });

  chrome.runtime.sendMessage({ type: 'FETCH_AUTO_LICENSE', email }, async response => {
    if (!response || !response.ok || !response.licenseKey) {
      chrome.storage.sync.set({
        licenseEmail: email,
        licenseKey: '',
        licenseValid: false,
        licenseStatus: response?.error || 'google_account_not_registered',
        licenseExpires: ''
      }, () => {
        $('saved').textContent = 'Google account not registered in Admin.';
        refreshStatusOnly();
      });
      return;
    }

    $('licenseKey').value = response.licenseKey;
    await verifyAndStoreLicense(email, response.licenseKey, 'google');
  });
}

function activateLicense() {
  const email = $('licenseEmail').value.trim().toLowerCase();
  const key = $('licenseKey').value.trim().toUpperCase();

  if (!email || !key) {
    $('saved').textContent = 'Add email and license key first.';
    return;
  }

  verifyAndStoreLicense(email, key, 'manual');
}

function clearLicense() {
  chrome.storage.sync.set({
    licenseEmail: '',
    licenseKey: '',
    licenseValid: false,
    licenseStatus: 'inactive',
    licenseExpires: '',
    licensePlan: '',
    licenseLoginSource: '',
  licenseApiUrl: 'https://relay-license-server.onrender.com/validate-license'
  }, () => {
    $('licenseEmail').value = '';
    $('licenseKey').value = '';
    $('saved').textContent = 'License cleared.';
    refreshStatusOnly();
    sendToContent('RCR_STOP');
  });
}


function checkUpdate() {
  const el = $('updateStatus');
  const link = $('downloadUpdate');
  if (el) el.textContent = 'Checking update...';
  if (link) link.style.display = 'none';

  const apiUrl = ($('licenseApiUrl')?.value || defaults.licenseApiUrl).trim();
  chrome.runtime.sendMessage({ type: 'CHECK_UPDATE', apiUrl, currentVersion: CURRENT_VERSION }, response => {
    if (!response || !response.ok) {
      if (el) el.textContent = 'Update check failed. Check server URL.';
      return;
    }

    if (response.updateAvailable) {
      if (el) el.textContent = `Update available: v${response.latestVersion}. Current: v${CURRENT_VERSION}`;
      if (link && response.downloadUrl) {
        link.href = response.downloadUrl;
        link.style.display = 'block';
      }
    } else {
      if (el) el.textContent = `You are up to date. v${CURRENT_VERSION}`;
    }
  });
}



async function autoActivateLicense(email) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({
      type: 'FETCH_AUTO_LICENSE',
      email
    }, response => {
      if (!response || !response.ok || !response.licenseKey) {
        resolve(false);
        return;
      }

      $('licenseKey').value = response.licenseKey;

      chrome.storage.sync.set({
        licenseEmail: email,
        licenseKey: response.licenseKey
      }, () => {
        if (typeof activateLicense === 'function') {
          activateLicense();
        }

        resolve(true);
      });
    });
  });
}


function startTrialCheckout() {
  const email = $('licenseEmail').value.trim().toLowerCase();

  if (!email) {
    const msg = $('trialMsg');
    if (msg) msg.textContent = 'Enter your email first.';
    $('saved').textContent = 'Enter your email first.';
    return;
  }

  chrome.storage.sync.set({ licenseEmail: email }, () => {});

  const msg = $('trialMsg');
  if (msg) msg.textContent = 'Opening secure Stripe Checkout...';

  
  chrome.runtime.sendMessage({ type: 'START_TRIAL_CHECKOUT', email }, response => {
    if (response && response.ok) {
      if (msg) msg.textContent = 'Stripe Checkout opened. Waiting for activation...';
      $('saved').textContent = 'Stripe Checkout opened.';

      let tries = 0;

      const timer = setInterval(async () => {
        tries++;

        const activated = await autoActivateLicense(email);

        if (activated) {
          clearInterval(timer);

          if (msg) msg.textContent = 'License activated automatically.';
          $('saved').textContent = 'License activated automatically.';
          return;
        }

        if (tries >= 30) {
          clearInterval(timer);

          if (msg) msg.textContent = 'Waiting for payment completion.';
        }
      }, 5000);

    } else {
      const error = response?.error || 'Could not open checkout.';
      if (msg) msg.textContent = error;
      $('saved').textContent = error;
    }
  });

}


function wireEvents() {
  $('save')?.addEventListener('click', save);
  $('activate')?.addEventListener('click', activateLicense);
  $('googleLogin')?.addEventListener('click', loginWithGoogle);
  $('clearLicense')?.addEventListener('click', clearLicense);
  $('start')?.addEventListener('click', () => sendToContent('RCR_START'));
  $('stop')?.addEventListener('click', () => sendToContent('RCR_STOP'));
  $('test')?.addEventListener('click', () => sendToContent('RCR_TEST'));
  $('baseline')?.addEventListener('click', () => sendToContent('RCR_BASELINE'));
  $('panel')?.addEventListener('click', () => sendToContent('RCR_TOGGLE_PANEL'));
  $('checkUpdate')?.addEventListener('click', checkUpdate);
  $('startTrial')?.addEventListener('click', startTrialCheckout);

  editableIds.forEach(id => {
    const el = $(id);
    if (!el) return;
    el.addEventListener('input', markTyping);
    el.addEventListener('focus', () => { userIsTyping = true; });
    el.addEventListener('blur', () => {
      setTimeout(() => { userIsTyping = false; }, 300);
    });
  });
}

wireEvents();
loadInitialSettings();
refreshStatusOnly();
setInterval(refreshStatusOnly, 1000);
setTimeout(checkUpdate, 1200);



$('testTelegram')?.addEventListener('click', async () => {
  const botToken = $('telegramBotToken')?.value?.trim();
  const chatId = $('telegramChatId')?.value?.trim();

  if (!botToken || !chatId) {
    $('saved').textContent = 'Please enter Telegram Bot Token and Chat ID.';
    return;
  }

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: '✅ Relay Tools Pro Telegram integration working.'
        })
      }
    );

    const data = await response.json();

    if (data.ok) {
      $('saved').textContent = 'Telegram test alert sent successfully.';
    } else {
      $('saved').textContent = 'Telegram API error.';
    }
  } catch (e) {
    $('saved').textContent = 'Failed to send Telegram alert.';
  }
});


$('testEmailAlert')?.addEventListener('click', async () => {
  const email = $('alertEmail')?.value?.trim();

  if (!email) {
    $('saved').textContent = 'Please enter alert email address.';
    return;
  }

  chrome.storage.local.set({
    rcrAlertEmail: email,
    rcrEmailMode: $('emailMode')?.value || 'Important Changes Only'
  });

  $('saved').textContent = 'Test email notification triggered.';

  try {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon128.png',
      title: 'Relay Tools Pro',
      message: `Email notification test sent to ${email}`
    });
  } catch (e) {}

  try {
    const tab = await getActiveTab();
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'RCR_EMAIL_TEST',
        email
      }, () => {});
    }
  } catch (e) {}
});

document.getElementById('saveBottom')?.addEventListener('click', () => {
  document.getElementById('save')?.click();
});


