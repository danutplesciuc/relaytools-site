Relay Contract Refresher V2.5 AUTO ACTIVATE

NEW:
- After Stripe payment, extension auto-fetches the license.
- License key auto-fills.
- Extension auto-activates.
- No copy/paste needed.

INSTALL:
1. Remove old extension
2. Load unpacked from /extension
3. Enter email
4. Click Start 7 Day Free Trial
5. Complete Stripe checkout
6. Extension activates automatically

IMPORTANT:
Keep your V2.3 persistent server running.
