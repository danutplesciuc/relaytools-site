
Relay Contract Refresher V2.6 SECURE ACTIVATION

NEW:
- Removed insecure /admin/licenses access.
- Extension now uses secure activation endpoint.
- Secret header required.
- Only the user's own license is returned.

IMPORTANT:
1. Patch server.js using SERVER-PATCH.txt
2. Add Render ENV:
RCR_API_SECRET=RCR_SECURE_2026
3. Deploy Render
4. Reload extension

RESULT:
- Users cannot see all licenses anymore.
- Auto activation still works.
